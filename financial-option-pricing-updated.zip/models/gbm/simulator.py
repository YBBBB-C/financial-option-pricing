"""Geometric Brownian Motion simulation engine.
几何布朗运动模拟引擎 - 用于资产价格路径模拟

Simulates asset price paths under the standard GBM SDE:
    dS_t = mu * S_t * dt + sigma * S_t * dW_t

which has the closed-form (exact) discretisation:
    S_{t+dt} = S_t * exp((mu - 0.5 * sigma^2) * dt + sigma * sqrt(dt) * Z)
where Z ~ N(0, 1).
"""

import numpy as np
from typing import Optional
from config.settings import GBM_DEFAULT_PARAMS
from utils.exceptions import DataValidationError
from utils.logger import setup_logger

logger = setup_logger(__name__)


class GBMSimulator:
    """Simulates asset price paths using Geometric Brownian Motion.
    使用几何布朗运动模拟资产价格路径
    """

    def __init__(
        self,
        mu: Optional[float] = None,
        sigma: Optional[float] = None,
        S0: Optional[float] = None,
        T: Optional[float] = None,
        n_steps: Optional[int] = None,
        seed: Optional[int] = None,
    ) -> None:
        """Initialise simulator with GBM parameters, falling back to config defaults.
        使用GBM参数初始化模拟器，未提供时使用config中的默认值

        Args:
            mu: Drift coefficient (annualised) / 漂移系数（年化）
            sigma: Volatility (annualised) / 波动率（年化）
            S0: Initial asset price / 初始资产价格
            T: Time horizon in years / 时间范围（年）
            n_steps: Number of discrete time steps / 离散时间步数
            seed: Random seed for reproducibility / 随机种子，用于结果复现
        """
        params = GBM_DEFAULT_PARAMS
        self.mu = mu if mu is not None else params["mu"]
        self.sigma = sigma if sigma is not None else params["sigma"]
        self.S0 = S0 if S0 is not None else params["S0"]
        self.T = T if T is not None else params["T"]
        self.n_steps = n_steps if n_steps is not None else params["n_steps"]
        self.dt = self.T / self.n_steps

        if self.S0 <= 0:
            raise DataValidationError(f"Initial price S0 must be positive, got {self.S0}")
        if self.sigma < 0:
            raise DataValidationError(f"Volatility sigma must be non-negative, got {self.sigma}")

        self._rng = np.random.default_rng(seed)
        logger.info(
            f"GBMSimulator initialised: mu={self.mu}, sigma={self.sigma}, "
            f"S0={self.S0}, T={self.T}, n_steps={self.n_steps}"
        )

    def simulate_paths(self, n_paths: int) -> np.ndarray:
        """Simulate n_paths independent GBM price paths.
        模拟n_paths条独立的GBM价格路径

        Uses the exact log-normal discretisation rather than an Euler scheme,
        so there is no discretisation bias regardless of dt.
        使用精确的对数正态离散化方法（而非欧拉格式），因此无论dt大小都不存在离散化偏差。

        Args:
            n_paths: Number of Monte Carlo paths to simulate / 模拟路径数量

        Returns:
            Array of shape (n_paths, n_steps + 1) containing simulated prices,
            including the initial price S0 at t=0.
            形状为 (n_paths, n_steps + 1) 的数组，包含t=0时的初始价格S0
        """
        if n_paths <= 0:
            raise DataValidationError(f"n_paths must be positive, got {n_paths}")

        Z = self._rng.standard_normal(size=(n_paths, self.n_steps))
        drift = (self.mu - 0.5 * self.sigma**2) * self.dt
        diffusion = self.sigma * np.sqrt(self.dt) * Z

        log_returns = drift + diffusion
        log_paths = np.concatenate(
            [np.zeros((n_paths, 1)), np.cumsum(log_returns, axis=1)], axis=1
        )
        paths = self.S0 * np.exp(log_paths)

        logger.info(f"Simulated {n_paths} GBM paths over {self.n_steps} steps")
        return paths

    def terminal_prices(self, n_paths: int) -> np.ndarray:
        """Simulate only the terminal price S_T for n_paths, without storing full paths.
        仅模拟n_paths条路径的终值S_T，不存储完整路径（内存效率更高）

        Uses the closed-form solution directly:
            S_T = S0 * exp((mu - 0.5*sigma^2)*T + sigma*sqrt(T)*Z)

        Args:
            n_paths: Number of Monte Carlo paths / 模拟路径数量

        Returns:
            Array of shape (n_paths,) containing terminal prices
        """
        if n_paths <= 0:
            raise DataValidationError(f"n_paths must be positive, got {n_paths}")

        Z = self._rng.standard_normal(size=n_paths)
        S_T = self.S0 * np.exp(
            (self.mu - 0.5 * self.sigma**2) * self.T + self.sigma * np.sqrt(self.T) * Z
        )
        return S_T
