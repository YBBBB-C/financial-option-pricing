"""Option pricing engines: Black-Scholes closed-form and Monte Carlo simulation.
期权定价引擎：Black-Scholes解析解与蒙特卡洛模拟

Both engines price European vanilla options and are cross-validated against
each other, since MC price should converge to the BS price as n_paths -> infinity.
两个引擎互为交叉验证：当路径数趋于无穷时，蒙特卡洛价格应收敛至Black-Scholes价格。
"""

import numpy as np
from scipy.stats import norm
from typing import Dict
from config.constants import OPTION_TYPE_CALL, OPTION_TYPE_PUT
from config.settings import OPTION_PRICING
from models.gbm.simulator import GBMSimulator
from utils.exceptions import PricingError
from utils.logger import setup_logger

logger = setup_logger(__name__)


class BlackScholesEngine:
    """Analytical Black-Scholes pricing for European vanilla options.
    欧式香草期权的Black-Scholes解析定价
    """

    def __init__(self, risk_free_rate: float = None) -> None:
        """
        Args:
            risk_free_rate: Annualised risk-free rate / 年化无风险利率
        """
        self.r = risk_free_rate if risk_free_rate is not None else OPTION_PRICING["risk_free_rate"]

    @staticmethod
    def _d1_d2(S: float, K: float, r: float, sigma: float, T: float) -> tuple:
        """Compute the standard d1, d2 terms used in the BS formula."""
        d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
        d2 = d1 - sigma * np.sqrt(T)
        return d1, d2

    def price(
        self, S: float, K: float, T: float, sigma: float, option_type: str = OPTION_TYPE_CALL
    ) -> float:
        """Price a European vanilla option using the closed-form BS formula.
        使用Black-Scholes解析公式为欧式香草期权定价

        Args:
            S: Current underlying price / 当前标的价格
            K: Strike price / 行权价
            T: Time to maturity in years / 到期时间（年）
            sigma: Annualised volatility / 年化波动率
            option_type: 'call' or 'put' / 期权类型

        Returns:
            Option price / 期权价格
        """
        if T <= 0 or sigma <= 0:
            raise PricingError(f"T and sigma must be positive, got T={T}, sigma={sigma}")

        d1, d2 = self._d1_d2(S, K, self.r, sigma, T)

        if option_type == OPTION_TYPE_CALL:
            price = S * norm.cdf(d1) - K * np.exp(-self.r * T) * norm.cdf(d2)
        elif option_type == OPTION_TYPE_PUT:
            price = K * np.exp(-self.r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)
        else:
            raise PricingError(f"Unknown option_type: {option_type}")

        return float(price)

    def greeks(
        self, S: float, K: float, T: float, sigma: float, option_type: str = OPTION_TYPE_CALL
    ) -> Dict[str, float]:
        """Compute analytical Greeks (Delta, Gamma, Vega, Theta, Rho).
        计算解析法希腊字母（Delta, Gamma, Vega, Theta, Rho）
        """
        d1, d2 = self._d1_d2(S, K, self.r, sigma, T)
        pdf_d1 = norm.pdf(d1)

        gamma = pdf_d1 / (S * sigma * np.sqrt(T))
        vega = S * pdf_d1 * np.sqrt(T) / 100  # per 1% vol change / 每1%波动率变化

        if option_type == OPTION_TYPE_CALL:
            delta = norm.cdf(d1)
            theta = (
                -S * pdf_d1 * sigma / (2 * np.sqrt(T))
                - self.r * K * np.exp(-self.r * T) * norm.cdf(d2)
            ) / 252  # per trading day / 每交易日
            rho = K * T * np.exp(-self.r * T) * norm.cdf(d2) / 100
        else:
            delta = norm.cdf(d1) - 1
            theta = (
                -S * pdf_d1 * sigma / (2 * np.sqrt(T))
                + self.r * K * np.exp(-self.r * T) * norm.cdf(-d2)
            ) / 252
            rho = -K * T * np.exp(-self.r * T) * norm.cdf(-d2) / 100

        return {"delta": delta, "gamma": gamma, "vega": vega, "theta": theta, "rho": rho}


class MonteCarloEngine:
    """Monte Carlo pricing for European vanilla options via GBM path simulation.
    通过GBM路径模拟对欧式香草期权进行蒙特卡洛定价
    """

    def __init__(self, risk_free_rate: float = None, n_paths: int = None, seed: int = None) -> None:
        """
        Args:
            risk_free_rate: Annualised risk-free rate / 年化无风险利率
            n_paths: Number of MC simulation paths / 蒙特卡洛模拟路径数
            seed: Random seed for reproducibility / 随机种子
        """
        self.r = risk_free_rate if risk_free_rate is not None else OPTION_PRICING["risk_free_rate"]
        self.n_paths = n_paths if n_paths is not None else OPTION_PRICING["mc_paths"]
        self.seed = seed

    def price(
        self, S: float, K: float, T: float, sigma: float, option_type: str = OPTION_TYPE_CALL
    ) -> Dict[str, float]:
        """Price a European vanilla option via Monte Carlo simulation, with standard error.
        通过蒙特卡洛模拟为欧式香草期权定价，并给出标准误差

        Uses risk-neutral GBM (mu = r) since we are pricing under the risk-neutral measure.
        使用风险中性GBM（漂移项mu设为无风险利率r），因为定价基于风险中性测度。

        Returns:
            Dict with 'price', 'std_error', and 'ci_95' (95% confidence interval width)
        """
        if T <= 0 or sigma <= 0:
            raise PricingError(f"T and sigma must be positive, got T={T}, sigma={sigma}")

        simulator = GBMSimulator(mu=self.r, sigma=sigma, S0=S, T=T, seed=self.seed)
        S_T = simulator.terminal_prices(self.n_paths)

        if option_type == OPTION_TYPE_CALL:
            payoffs = np.maximum(S_T - K, 0.0)
        elif option_type == OPTION_TYPE_PUT:
            payoffs = np.maximum(K - S_T, 0.0)
        else:
            raise PricingError(f"Unknown option_type: {option_type}")

        discounted_payoffs = np.exp(-self.r * T) * payoffs
        price = float(np.mean(discounted_payoffs))
        std_error = float(np.std(discounted_payoffs, ddof=1) / np.sqrt(self.n_paths))

        logger.info(
            f"MC price ({option_type}, n_paths={self.n_paths}): "
            f"{price:.4f} +/- {1.96 * std_error:.4f} (95% CI)"
        )

        return {"price": price, "std_error": std_error, "ci_95": 1.96 * std_error}


def cross_validate(S: float, K: float, T: float, sigma: float, option_type: str = OPTION_TYPE_CALL) -> Dict[str, float]:
    """Cross-validate MC pricing against the BS closed-form solution.
    将蒙特卡洛定价与Black-Scholes解析解进行交叉验证

    Returns:
        Dict comparing both engines' prices and the absolute/relative pricing error
    """
    bs_engine = BlackScholesEngine()
    mc_engine = MonteCarloEngine(seed=42)

    bs_price = bs_engine.price(S, K, T, sigma, option_type)
    mc_result = mc_engine.price(S, K, T, sigma, option_type)

    abs_error = abs(mc_result["price"] - bs_price)
    rel_error = abs_error / bs_price if bs_price != 0 else float("nan")

    within_ci = abs_error <= mc_result["ci_95"]

    logger.info(
        f"Cross-validation: BS={bs_price:.4f}, MC={mc_result['price']:.4f}, "
        f"abs_error={abs_error:.4f}, within_95_CI={within_ci}"
    )

    return {
        "bs_price": bs_price,
        "mc_price": mc_result["price"],
        "abs_error": abs_error,
        "rel_error": rel_error,
        "mc_ci_95": mc_result["ci_95"],
        "within_ci": within_ci,
    }
